﻿namespace CIS
{
    partial class Home
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGrid = new System.Windows.Forms.DataGridView();
            this.lblSelect = new System.Windows.Forms.Label();
            this.Cb_Rst_List = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGrid)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGrid
            // 
            this.dataGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGrid.Location = new System.Drawing.Point(50, 80);
            this.dataGrid.Name = "dataGrid";
            this.dataGrid.Size = new System.Drawing.Size(883, 384);
            this.dataGrid.TabIndex = 0;
            // 
            // lblSelect
            // 
            this.lblSelect.AutoSize = true;
            this.lblSelect.Location = new System.Drawing.Point(47, 16);
            this.lblSelect.Name = "lblSelect";
            this.lblSelect.Size = new System.Drawing.Size(155, 13);
            this.lblSelect.TabIndex = 2;
            this.lblSelect.Text = "Select SRT and Players  Data :";
            // 
            // Cb_Rst_List
            // 
            this.Cb_Rst_List.FormattingEnabled = true;
            this.Cb_Rst_List.Items.AddRange(new object[] {
            "SELECT * FROM R and S",
            "SELECT * FROM R, S, T WHERE R.B = S.B",
            "SELECT R.A and S.C FROM R, S WHERE R.B = S.B",
            "SELECT R.A and T.D FROM R, S, T WHERE (R.B = S.B) AND (S.C < T.C)",
            "SELECT FIRSTNAME, LASTNAME, WEIGHT, BIRTHDATE FROM PLAYERS WHERE WEIGHT>200",
            "SELECT FIRSTNAME, LASTNAME, WEIGHT, BIRTHDATE FROM PLAYERS WHERE BIRTHDATE > \'199" +
                "0-01-01\'",
            "SELECT FIRSTNAME, LASTNAME, WEIGHT, BIRTHDATE FROM PLAYERS WHERE WEIGHT<135",
            "SELECT * FROM PLAYERS WHERE BIRTHDATE > \'1990-01-01\'",
            "SELECT * FROM PLAYERS WHERE WEIGHT<135",
            "SELECT P1.FIRSTNAME, P1.LASTNAME FROM PLAYERS P1, PLAYERS P2 WHERE P1.WEIGHT = P2" +
                ".WEIGHT AND P1.WEIGHT = 325 AND FIRSTNAME=\'Priest\'"});
            this.Cb_Rst_List.Location = new System.Drawing.Point(228, 13);
            this.Cb_Rst_List.Name = "Cb_Rst_List";
            this.Cb_Rst_List.Size = new System.Drawing.Size(705, 21);
            this.Cb_Rst_List.TabIndex = 5;
            this.Cb_Rst_List.Text = "--Select--";
            this.Cb_Rst_List.SelectedIndexChanged += new System.EventHandler(this.Cb_Rst_List_SelectedIndexChanged);
            // 
            // Home
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1094, 497);
            this.Controls.Add(this.Cb_Rst_List);
            this.Controls.Add(this.lblSelect);
            this.Controls.Add(this.dataGrid);
            this.Name = "Home";
            this.Text = "Home";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Home_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGrid)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGrid;
        private System.Windows.Forms.Label lblSelect;
        private System.Windows.Forms.ComboBox Cb_Rst_List;
    }
}