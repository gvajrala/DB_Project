using System;
using System.Data;
using System.IO;
using System.Windows.Forms;
namespace Cis552
{
    public partial class Cis552 : Form
    {
        string filterForRst = "";
        int[] rDataA = new int[10];
        int[] rDataB = new int[10];

        int[] sDataB = new int[10];
        int[] sDataC = new int[10];

        int[] tDataC = new int[10];
        int[] tDataD = new int[10];
        public Cis552()
        {
            InitializeComponent();
        }

        private void Cis552_Load(object sender, EventArgs e)
        {
            string _filePathR = "C:\\Data\\r.dat";
            string _filePathS = "C:\\Data\\s.dat";
            string _filePathT = "C:\\Data\\t.dat";

            filldataToArrays(_filePathR, "R");
            filldataToArrays(_filePathS, "S");
            filldataToArrays(_filePathT, "T");
        }
        private void filldataToArrays(string filePath, string data)
        {
            int i = 0;
            string[] lines = System.IO.File.ReadAllLines(filePath);
            foreach (string line in lines)
            {
                var cols = line.Split('|');
                if (data == "R")
                {
                    rDataA[i] = Convert.ToInt16(cols[0]);
                    rDataB[i] = Convert.ToInt16(cols[1]);
                }
                else if (data == "S")
                {
                    sDataB[i] = Convert.ToInt16(cols[0]);
                    sDataC[i] = Convert.ToInt16(cols[1]);
                }
                else if (data == "T")
                {
                    tDataC[i] = Convert.ToInt16(cols[0]);
                    tDataD[i] = Convert.ToInt16(cols[1]);
                }
                i = i + 1;
            }
        }

        private DataTable ConvertToDataTable(int condition)
        {
            DataTable tbl = new DataTable();
            string _filePath = "C:\\Data\\PLAYERS.dat";

            if (condition == 0 || condition == 1 || condition == 2)
            {
                string[] colNames = { "FIRSTNAME", "LASTNAME", "WEIGHT", "BIRTHDATE" };

                for (int col = 0; col < colNames.Length; col++)
                    tbl.Columns.Add(new DataColumn(colNames[col].ToString()));
            }
            else if (condition == 3 || condition == 4)
            {
                string[] colNames = { "ID", "FIRSTNAME", "LASTNAME", "FIRSTSEASON", "LASTSEASON", "WEIGHT", "BIRTHDATE" };

                for (int col = 0; col < colNames.Length; col++)
                    tbl.Columns.Add(new DataColumn(colNames[col].ToString()));
            }
            else if (condition == 5)
            {
                string[] colNames = { "FIRSTNAME", "LASTNAME" };

                for (int col = 0; col < colNames.Length; col++)
                    tbl.Columns.Add(new DataColumn(colNames[col].ToString()));
            }

            string[] lines = System.IO.File.ReadAllLines(_filePath);

            foreach (string line in lines)
            {
                var cols = line.Split('|');

                DataRow dr = tbl.NewRow();
                if (condition == 0)
                {
                    if (Convert.ToInt16(cols[5]) > 200)
                    {
                        dr[0] = cols[1];
                        dr[1] = cols[2];
                        dr[2] = cols[5];
                        dr[3] = cols[6];
                        tbl.Rows.Add(dr);
                    }
                }
                else if (condition == 1)
                {
                    DateTime bDate = Convert.ToDateTime(cols[6]);
                    DateTime date = Convert.ToDateTime("1990-01-01");
                    if (bDate > date)
                    {
                        dr[0] = cols[1];
                        dr[1] = cols[2];
                        dr[2] = cols[5];
                        dr[3] = cols[6];
                        tbl.Rows.Add(dr);
                    }
                }
                else if (condition == 2)
                {
                    if (Convert.ToInt16(cols[5]) < 135)
                    {
                        dr[0] = cols[1];
                        dr[1] = cols[2];
                        dr[2] = cols[5];
                        dr[3] = cols[6];
                        tbl.Rows.Add(dr);
                    }
                }
                else if (condition == 3)
                {
                    DateTime bDate = Convert.ToDateTime(cols[6]);
                    DateTime date = Convert.ToDateTime("1990-01-01");
                    if (bDate > date)
                    {
                        for (int j = 0; j < 7; j++)
                        {
                            dr[j] = cols[j];
                        }
                        tbl.Rows.Add(dr);
                    }
                }
                else if (condition == 4)
                {
                    if (Convert.ToInt16(cols[5]) < 135)
                    {
                        for (int j = 0; j < 7; j++)
                        {
                            dr[j] = cols[j];
                        }
                        tbl.Rows.Add(dr);
                    }
                }
                else if (condition == 5)
                {
                    if (cols[1] == "Priest")
                    {
                        dr[0] = cols[1];
                        dr[1] = cols[2];
                        tbl.Rows.Add(dr);
                    }
                }
            }
            return tbl;
        }

        private void Cb_Rst_List_SelectedIndexChanged(object sender, EventArgs e)
        {
            DataTable dt = new DataTable();
            filterForRst = Cb_Rst_List.SelectedItem.ToString();
            string _filePath = Path.GetDirectoryName(System.AppDomain.CurrentDomain.BaseDirectory);
            switch (filterForRst)
            {
                case "SELECT * FROM R and S":
                    {
                        dt.Columns.Add(new DataColumn("R.A"));
                        dt.Columns.Add(new DataColumn("R.B"));
                        dt.Columns.Add(new DataColumn("S.B"));
                        dt.Columns.Add(new DataColumn("S.C"));
                        for (int i = 0; i < rDataA.Length; i++)
                        {
                            DataRow dr = dt.NewRow();
                            dr[0] = rDataA[i];
                            dr[1] = rDataB[i];
                            dr[2] = sDataB[i];
                            dr[3] = sDataB[i];
                            dt.Rows.Add(dr);
                        }
                    }
                    break;
                case "SELECT * FROM R, S, T WHERE R.B = S.B":
                    {
                        dt.Columns.Add(new DataColumn("R.A"));
                        dt.Columns.Add(new DataColumn("R.B"));
                        dt.Columns.Add(new DataColumn("S.B"));
                        dt.Columns.Add(new DataColumn("S.C"));
                        dt.Columns.Add(new DataColumn("T.C"));
                        dt.Columns.Add(new DataColumn("T.D"));
                        Array.Sort(rDataB);
                        Array.Sort(sDataB);
                        for (int i = 0; i < rDataA.Length; i++)
                        {
                            if (rDataB[i] == sDataB[i])
                            {
                                DataRow dr = dt.NewRow();
                                dr[0] = rDataA[i];
                                dr[1] = rDataB[i];
                                dr[2] = sDataB[i];
                                dr[3] = sDataC[i];
                                dr[4] = tDataC[i];
                                dr[5] = tDataD[i];
                                dt.Rows.Add(dr);
                            }
                        }
                    }
                    break;
                case "SELECT R.A and S.C FROM R, S WHERE R.B = S.B":
                    {
                        dt.Columns.Add(new DataColumn("R.A"));
                        dt.Columns.Add(new DataColumn("S.C"));

                        for (int i = 0; i < rDataA.Length; i++)
                        {
                            if (rDataB[i] == sDataB[i])
                            {
                                DataRow dr = dt.NewRow();
                                dr[0] = rDataA[i];
                                dr[1] = sDataC[i];
                                dt.Rows.Add(dr);
                            }
                        }
                    }
                    break;
                case "SELECT R.A and T.D FROM R, S, T WHERE (R.B = S.B) AND (S.C < T.C)":
                    {
                        dt.Columns.Add(new DataColumn("R.A"));
                        dt.Columns.Add(new DataColumn("T.D"));
                        Array.Sort(rDataB);
                        Array.Sort(sDataB);
                        Array.Sort(sDataC);
                        Array.Sort(tDataC);
                        for (int i = 0; i < rDataA.Length; i++)
                        {
                            if (rDataB[i] == sDataB[i] && sDataC[i] < tDataC[i])
                            {
                                DataRow dr = dt.NewRow();
                                dr[0] = rDataA[i];
                                dr[1] = tDataD[i];
                                dt.Rows.Add(dr);
                            }
                        }
                    }
                    break;
                case "SELECT FIRSTNAME, LASTNAME, WEIGHT, BIRTHDATE FROM PLAYERS WHERE WEIGHT>200":
                    {
                        int condition = 0;
                        dt = ConvertToDataTable(condition);
                    }
                    break;
                case "SELECT FIRSTNAME, LASTNAME, WEIGHT, BIRTHDATE FROM PLAYERS WHERE BIRTHDATE > '1990-01-01'":
                    {
                        int condition = 1;
                        dt = ConvertToDataTable(condition);
                    }
                    break;
                case "SELECT FIRSTNAME, LASTNAME, WEIGHT, BIRTHDATE FROM PLAYERS WHERE WEIGHT<135":
                    {
                        int condition = 2;
                        dt = ConvertToDataTable(condition);
                    }
                    break;
                case "SELECT * FROM PLAYERS WHERE BIRTHDATE > '1990-01-01'":
                    {
                        int condition = 3;
                        dt = ConvertToDataTable(condition);
                    }
                    break;
                case "SELECT * FROM PLAYERS WHERE WEIGHT<135":
                    {
                        int condition = 4;
                        dt = ConvertToDataTable(condition);
                    }
                    break;
                case "SELECT P1.FIRSTNAME, P1.LASTNAME FROM PLAYERS P1, PLAYERS P2 WHERE P1.WEIGHT = P2.WEIGHT AND P1.WEIGHT = 325 AND FIRSTNAME='Priest'":
                    {
                        int condition = 5;
                        dt = ConvertToDataTable(condition);
                    }
                    break;
            }
            dataGrid.DataSource = dt;
            dataGrid.Focus();
        }

        private void Cb_Rst_List_SelectedIndexChanged_1(object sender, EventArgs e)
        {

        }
    }
}