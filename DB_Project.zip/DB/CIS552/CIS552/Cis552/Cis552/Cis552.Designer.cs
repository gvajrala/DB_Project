﻿namespace Cis552
{
    partial class Cis552
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Cb_Rst_List = new System.Windows.Forms.ComboBox();
            this.lblSelect = new System.Windows.Forms.Label();
            this.dataGrid = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dataGrid)).BeginInit();
            this.SuspendLayout();
            // 
            // Cb_Rst_List
            // 
            this.Cb_Rst_List.FormattingEnabled = true;
            this.Cb_Rst_List.Items.AddRange(new object[] {
            "SELECT * FROM R and S",
            "SELECT * FROM R, S, T WHERE R.B = S.B",
            "SELECT R.A and S.C FROM R, S WHERE R.B = S.B",
            "SELECT R.A and T.D FROM R, S, T WHERE (R.B = S.B) AND (S.C < T.C)",
            "SELECT FIRSTNAME, LASTNAME, WEIGHT, BIRTHDATE FROM PLAYERS WHERE WEIGHT>200",
            "SELECT FIRSTNAME, LASTNAME, WEIGHT, BIRTHDATE FROM PLAYERS WHERE BIRTHDATE > \'199" +
                "0-01-01\'",
            "SELECT FIRSTNAME, LASTNAME, WEIGHT, BIRTHDATE FROM PLAYERS WHERE WEIGHT<135",
            "SELECT * FROM PLAYERS WHERE BIRTHDATE > \'1990-01-01\'",
            "SELECT * FROM PLAYERS WHERE WEIGHT<135",
            "SELECT P1.FIRSTNAME, P1.LASTNAME FROM PLAYERS P1, PLAYERS P2 WHERE P1.WEIGHT = P2" +
                ".WEIGHT AND P1.WEIGHT = 325 AND FIRSTNAME=\'Priest\'"});
            this.Cb_Rst_List.Location = new System.Drawing.Point(350, 28);
            this.Cb_Rst_List.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Cb_Rst_List.Name = "Cb_Rst_List";
            this.Cb_Rst_List.Size = new System.Drawing.Size(939, 28);
            this.Cb_Rst_List.TabIndex = 8;
            this.Cb_Rst_List.Text = "--Select--";
            this.Cb_Rst_List.SelectedIndexChanged += new System.EventHandler(this.Cb_Rst_List_SelectedIndexChanged);
            // 
            // lblSelect
            // 
            this.lblSelect.AutoSize = true;
            this.lblSelect.Location = new System.Drawing.Point(109, 33);
            this.lblSelect.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblSelect.Name = "lblSelect";
            this.lblSelect.Size = new System.Drawing.Size(203, 20);
            this.lblSelect.TabIndex = 7;
            this.lblSelect.Text = "Select SRT and Players  Data :";
            // 
            // dataGrid
            // 
            this.dataGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGrid.Location = new System.Drawing.Point(113, 131);
            this.dataGrid.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.dataGrid.Name = "dataGrid";
            this.dataGrid.RowHeadersWidth = 51;
            this.dataGrid.Size = new System.Drawing.Size(1177, 591);
            this.dataGrid.TabIndex = 6;
            // 
            // Cis552
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1398, 751);
            this.Controls.Add(this.Cb_Rst_List);
            this.Controls.Add(this.lblSelect);
            this.Controls.Add(this.dataGrid);
            this.Name = "Cis552";
            this.Text = "CIS552";
            this.Load += new System.EventHandler(this.Cis552_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGrid)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private ComboBox Cb_Rst_List;
        private Label lblSelect;
        private DataGridView dataGrid;
    }
}